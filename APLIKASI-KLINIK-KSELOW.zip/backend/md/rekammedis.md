{
  "pasien": "6927e4e391554025cd4b59ba", 
  "keluhan": "Batuk kering dan demam selama 3 hari",
  "dokter": "Dr. Siti Aisyah",
  "beratBadan": 65.5,
  "tekananDarah": "120/80",
  "suhuBadan": 38.2,
  "diagnosa": "Common cold",
  "resep": ["Paracetamol 500mg"],
  "catatan": "Pasien disarankan istirahat cukup."
}